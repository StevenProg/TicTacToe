public class SavingsAccount{
    private int balance;
    private int initialBalance;

    public SavingsAccount(){
        balance = 0;
    }

    public SavingsAccount(int initialBalance){
        balance = initialBalance;
    }

    public void greet(){
        System.out.println("Hi");
    }

    public void showBalance(){
        System.out.println(balance);
    }

    public void deposit(int howMuch) {
        if (howMuch < 0){
            System.out.println("Negative amount");
        }
        else {
            balance = balance + howMuch;
        }
    }

    public void withdraw(int howMuch) {
        if (howMuch < 0){
            System.out.println("Negative amount");
        }
        else {
            balance = balance - howMuch;
        }
    }
}
